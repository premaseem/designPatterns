package com.premaseem.strategy;

public interface AirthematicOperationStrategy {

	public Integer performOperation(Integer num1, Integer num2);
	
}
